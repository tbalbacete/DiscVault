const axios = require("axios");
const cheerio = require("cheerio");

exports.handler = async (event) => {
  const url = "https://www.marshallstreetdiscgolf.com/flightguide";

  try {
    const response = await axios.get(url);
    const html = response.data;

    // Load the HTML into cheerio
    const $ = cheerio.load(html);

    // Example: Extract the title of the page
    const pageTitle = $("title").text();

    // Example: Extract all links from the page
    const links = [];
    $("a").each((index, element) => {
      links.push({
        text: $(element).text(),
        href: $(element).attr("href"),
      });
    });

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "HTML parsed successfully",
        pageTitle: pageTitle,
        links: links,
      }),
    };
  } catch (error) {
    console.error("Error fetching or parsing the HTML:", error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Error fetching or parsing the HTML",
        error: error.message,
      }),
    };
  }
};
